# Importing libraries
import numpy as np
import pandas as pd
from scipy.stats import mode
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
import pickle
import joblib


#get_ipython().run_line_magic('matplotlib', 'inline')


# In[17]:


# Reading the train.csv by removing the
# last column since it's an empty column
DATA_PATH = "Training.csv"
data = pd.read_csv(DATA_PATH).dropna(axis = 1)


# Encoding the target value into numerical
# value using LabelEncoder
encoder = LabelEncoder()
data["prognosis"] = encoder.fit_transform(data["prognosis"])


encoder_filename = 'label_encoder.pkl'
joblib.dump(encoder, encoder_filename)

X = data.iloc[:, :-1]
y = data.iloc[:, -1]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=24)

# Define scoring metric for k-fold cross-validation
def cv_scoring(estimator, X, y):
    return accuracy_score(y, estimator.predict(X))

# Initialize Models
models = {
    "SVC": SVC(),
    "Gaussian NB": GaussianNB(),
    "Random Forest": RandomForestClassifier(random_state=18)
}

# Produce cross-validation scores for the models
for model_name in models:
    model = models[model_name]
    scores = cross_val_score(model, X, y, cv=10,
                             n_jobs=-1,
                             scoring=cv_scoring)
    print("=="*30)
    print(model_name)
    print(f"Scores: {scores}")
    print(f"Mean Score: {np.mean(scores)}")

# Train and test SVM Classifier
svm_model = SVC()
svm_model.fit(X_train, y_train)
preds = svm_model.predict(X_test)

print(f"Accuracy on train data by SVM Classifier: {accuracy_score(y_train, svm_model.predict(X_train))*100}")
print(f"Accuracy on test data by SVM Classifier: {accuracy_score(y_test, preds)*100}")
cf_matrix = confusion_matrix(y_test, preds)
plt.figure(figsize=(12, 8))
sns.heatmap(cf_matrix, annot=True)
plt.title("Confusion Matrix for SVM Classifier on Test Data")
plt.show()

# Train and test Naive Bayes Classifier
nb_model = GaussianNB()
nb_model.fit(X_train, y_train)
preds = nb_model.predict(X_test)
print(f"Accuracy on train data by Naive Bayes Classifier: {accuracy_score(y_train, nb_model.predict(X_train))*100}")
print(f"Accuracy on test data by Naive Bayes Classifier: {accuracy_score(y_test, preds)*100}")
cf_matrix = confusion_matrix(y_test, preds)
plt.figure(figsize=(12, 8))
sns.heatmap(cf_matrix, annot=True)
plt.title("Confusion Matrix for Naive Bayes Classifier on Test Data")
plt.show()

# Train and test Random Forest Classifier
rf_model = RandomForestClassifier(random_state=18)
rf_model.fit(X_train, y_train)
preds = rf_model.predict(X_test)
print(f"Accuracy on train data by Random Forest Classifier: {accuracy_score(y_train, rf_model.predict(X_train))*100}")
print(f"Accuracy on test data by Random Forest Classifier: {accuracy_score(y_test, preds)*100}")
cf_matrix = confusion_matrix(y_test, preds)
plt.figure(figsize=(12, 8))
sns.heatmap(cf_matrix, annot=True)
plt.title("Confusion Matrix for Random Forest Classifier on Test Data")
plt.show()

# Train the models on the entire dataset
final_svm_model = SVC()
final_nb_model = GaussianNB()
final_rf_model = RandomForestClassifier(random_state=18)
final_svm_model.fit(X, y)
final_nb_model.fit(X, y)
final_rf_model.fit(X, y)

# Save the final trained models
with open('final_svm_model.pkl', 'wb') as svm_model_file:
    pickle.dump(final_svm_model, svm_model_file)

with open('final_nb_model.pkl', 'wb') as nb_model_file:
    pickle.dump(final_nb_model, nb_model_file)

with open('final_rf_model.pkl', 'wb') as rf_model_file:
    pickle.dump(final_rf_model, rf_model_file)

# Continue with testing or deployment as needed
# ...

# Define a function to make predictions using the loaded model
def predict_prognosis(input_data, model):
    return model.predict(input_data)

# Testing the function
symptoms = "Joint Pain,Spotting urination,Fatigue,Indigestion,Loss Of Appetite,Back Pain,Blurred And Distorted Vision,Swollen Legs,Muscle Weakness,Movement Stiffness,Loss Of Balance,Unsteadiness,Red Spots Over Body,Painful Walking,Swollen Legs,Slurred Speech"
input_data = pd.DataFrame(columns=X.columns)
for symptom in symptoms.split(','):
    input_data[symptom] = [1]

with open('final_rf_model.pkl', 'rb') as rf_model_file:
    loaded_rf_model = pickle.load(rf_model_file)

prediction = loaded_rf_model.predict(input_data)
print(f"Prediction for symptoms: {symptoms}")
print(f"Predicted Disease: {encoder.inverse_transform(prediction)[0]}")
